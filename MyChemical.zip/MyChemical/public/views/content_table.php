<!DOCTYPE html>

<head>
    <link rel="stylesheet" type="text/css" href="../public/css/style.css">
    <link rel="stylesheet" type="text/css" href="../public/css/style_home.css">
    <link rel="stylesheet" type="text/css" href="../public/css/style_po_zalogowaniu.css">
    <link rel="stylesheet" type="text/css" href="../public/css/style_content_table.css">

    <script type="text/javascript" src=".././public/js/heart.js" defer ></script>
    <script src="https://kit.fontawesome.com/7b3efb56a6.js" crossorigin="anonymous"></script>
    <title>LOGIN PAGE</title>
</head>

<body>

    <div class="top_container">
        <div class="pasek_menu_two">
            <div class="menu_main">
                <ul>
                    <li ><a href="../board">My board</a></li>
                    <li ><a  href="../seeAllTables">Tables</a></li>
                    <li ><a  href="calculators">Calculators</a></li>
                    <li ><a  href="reactions">Search reaction</a></li>
                </ul>
            </div>
        </div>
    </div>



    <div class="pasek_menu">
        <img  src="../public/img/logo_blekitne.png">
        <div class="menu">
            <ul>
                <li ><i class="fas fa-sign-out-alt"></i><a href="index"> Logout</a></li>
                <li id="active_one"><a  href="account">My account</a></li>
            </ul>
        </div>
    </div>



    <div class="middle_container_out">

        <div class="middle_container_tab">
            <?php foreach ($tables as $table): ?>

                <div id="<?=$table->getIdTable()?>">
                    <img src="../public/img/img_content_table/<?= $table->getImageContentTable(); ?>">
                    <div class="linia">
                        <button class="serce"><i class="far fa-heart fa-lg"></i></button>
                        <button class="podpis_tabela" ><?= $table->getNameTable(); ?></button>
                    </div>

                </div>

            <?php endforeach; ?>
        </div>


    </div>






    <div class="bottom_container">

        <div class="top_container_text">
            <div id="basic_text">
                <p>Discover chemistry</p>
                <p id="green_text">in THE MOST</p>
                <p id="green_text">CONVENIENT</p>
                <p>way</p>
            </div>
        </div>

        <div id="kontakt">
            <p>Masz pytanie?<br>Skontaktuj się z nami przez adres <br><b>mychemical@gmail.com</b></p>
        </div>
        <div id="spolecznosc">
            <p>Znajdź nas również na</p>
            <div id="ikony">
                <i class="fab fa-facebook-square fa-lg"></i>
                <i class="fab fa-instagram fa-lg"></i>
                <i class="fab fa-snapchat-square fa-lg"></i>
             </div>
        </div>
    </div>
</body>
