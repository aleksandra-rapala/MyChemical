//najpierw pobieramy wszystkie przyciski, które sa powiązane z serduszkami

//ponieważ chcemy pobrac wszystkie przyciski z całej strony projektów to pobieramy je sobie za pomocą
// querySelectorAll


const likeButtons = document.querySelectorAll(".serce");
const dislikeButtons = document.querySelectorAll(".serce_puste");


//dla każdego z tych przycisków musimy nadac zdarzenie zatem
//musimy po całej tej liście przycisków iterować, a nastepnie dla każdego pojedynczego przycisku przypisać eventlisyner?



function giveLike() {
    const likes = this; //button który kliknelismy  ponieważ my klikneliśmy na ten element on będzie pod nazwą this

    //musimy w jakiś sposób pobrać id
    //zatem względem tego elementu który kliknelismy idziemy po rodzicach tam gdzie jest id naszego kalkulatora/projektu/tablicy
    const container = likes.parentElement.parentElement.parentElement;

    //musimy w jakiś sposób pobrać id
    const id = container.getAttribute("id");  //zatem mamy id np kalkulatora

    fetch(`/likeSelectTable/${id}`) //wywołujemy endpoint, czyli akcję likeSelectCalculator i przekazujemy argument
        .then(function () {
            likes.innerHTML = `<i class="fas fa-heart fa-lg"></i>`;
        })
}


function giveDislike() {
    const dislikes = this;
    const container = dislikes.parentElement.parentElement.parentElement;
    const id = container.getAttribute("id");

    fetch(`/dislikeSelectTable/${id}`)
        .then(function () {
            dislikes.innerHTML = `<i class="far fa-heart fa-lg"></i>`;
        })
}


likeButtons.forEach(button => button.addEventListener("click", giveLike));
dislikeButtons.forEach(button => button.addEventListener("click", giveDislike));