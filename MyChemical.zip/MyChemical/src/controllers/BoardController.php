<?php

require_once 'AppController.php';
require_once __DIR__ . '/../models/Board.php';
require_once __DIR__ . '/../repository/BoardRepository.php';


require_once __DIR__ . '/../models/Calculator.php';
require_once __DIR__ . '/../models/Table.php';
require_once __DIR__ . '/../repository/CalculatorRepository.php';
require_once __DIR__ . '/../repository/TableRepository.php';


class BoardController extends AppController
{

    //private $message = [];
    private $boardRepository;



    public function __construct()
    {
        parent::__construct();
        $this->boardRepository = new BoardRepository();
    }



    public function seeUserBoard(int $id_user)
    {
        //wyswietlamy widok html calculator z podanymi argumentami


        //  TO DO wysłać 3 tablice a narazie 2 tylko bo kalkulatory + tablice

        $calculatorRepository = new CalculatorRepository();
        $tableRepository = new TableRepository();

        $calculators = $calculatorRepository->getUserCalculator($id_user);
        $tables = $tableRepository->getUserTable($id_user);


        $this->render('board', ['calculators' => $calculators, 'tables' => $tables]);


    }





}