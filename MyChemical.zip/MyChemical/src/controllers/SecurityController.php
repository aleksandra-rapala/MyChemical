<?php

require_once 'AppController.php';
require_once __DIR__ .'/../models/User.php';
require_once __DIR__.'/../repository/UserRepository.php';
require_once __DIR__.'/../repository/BoardRepository.php';


class SecurityController extends AppController {


    public function logowanie()
    {   

        //tworzenie repozytorium użytkowników
        $userRepository = new UserRepository();


        // jesli dane nie zostaly przeslane dalej chcemy strone logowania czyli widok login
        if (!$this->isPost()) {
            return $this->render('login');
        }

        //przechwycenie emailu oraz passwordu
        $email = $_POST['email'];      //name w input atrybuty mówią pod jakim kluczme przyjda do kontrolera
        $password = $_POST['password'];


        //szukamy uzytkownika o danym emailu
        $user = $userRepository->getUser($email);


        //jeśli user jest null tzn. że nie istnieje //zwracamy ekran logowania z wiadomościami
        if(!$user){
            return $this->render('login', ['messages'=> ['User with this email not exist!']]);
        }


        else if ($user->getPassword() !== $password) {
            return $this->render('login', ['messages' => ['Wrong password!']]);
        }






        //tu renderujemy widok board ALE z parametrami zatem powinniśmy tu wykonać akcję seeUserBoard
        //tu normalnie nie przekazujemy 1 tylko pobieramy id_user
        else return Routing::run('seeUserBoard/1');

        //$this->render('board');


        //tu można zrobić też inne zwracanie
    }





    public function rejestracja(){

        //tworzenie repozytorium użytkowników
        $userRepository = new UserRepository();

        // jesli dane nie zostaly przeslane dalej chcemy strone logowania czyli widok login
        if (!$this->isPost()) {
            return $this->render('register');
        }

        //przechwycenie emailu oraz passwordu
        $email = $_POST['email'];
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        //szukamy uzytkownika o danym emailu
        $user = $userRepository->getUser($email);


        //jeśli user jest null tzn. że nie istnieje jeszcze taki użytkownik zatem sprawdzamy hasła
        if(!$user){
            if ($password !== $confirm_password) {
                return $this->render('register', ['messages' => ['Wrong password!']]);
            }
            else {

                //TO DO tutaj stworzyc nowego uzytkownika z tymi danymi oraz nową board
                //najpierw stworzyc nowa board a potem te numer id board przypisać przy tworzeniu użytkownika


                //tworzymy użytkownika
               $userRepository->createNewUser(new User($email, $password));




                //tworzenie repozytorium board
               $boardRepository = new BoardRepository();

              //  $actual_id_board = $boardRepository->createNewBoard();





               // $userRepository->giveBoardUser($actual_id_board, $id_user);

                //TO DO ZAAKTUALIZUJ TEGO UZYTKOWNIKA PRZYPISUJĄC MU BOARD


                //tu normalnie nie przekazujemy 1 tylko pobieramy id_user
             return Routing::run('seeUserBoard/1');
            }
        }

        else return $this->render('register', ['messages'=> ['User with this email already exist!']]);


    }
    
}