<?php

require_once 'AppController.php';
require_once __DIR__ . '/../models/Calculator.php';
require_once __DIR__ . '/../repository/CalculatorRepository.php';


class CalculatorController extends AppController
{

    //private $message = [];
    private $calculatorRepository;


    public function __construct()
    {
        parent::__construct();
        $this->calculatorRepository = new CalculatorRepository();
    }


    public function seeAllCalculators()
    {
        //wyswietlamy widok html calculator z podanymi argumentami
        $calculators = $this->calculatorRepository->getAllCalculators();
        $this->render('calculators', ['calculators' => $calculators]);
    }


//polikowanie to tak naprawde stworzenie nowego wpisu do repozytorium
//id calculatora które zostanie tak naprawde zmapowane ze ścieżki Urla //id board mozna pobrac z aktywnej sesji

    public function likeSelectCalculator(int $id_board, int $id_calculator) {
        $this->calculatorRepository->likeCalculator($id_board, $id_calculator);
        http_response_code(200);
    }

    public function dislikeSelectCalculator(int $id_board, int $id_calculator) {
        $this->calculatorRepository->dislikeCalculator($id_board, $id_calculator);
        http_response_code(200);
    }



}