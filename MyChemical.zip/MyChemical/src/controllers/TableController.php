<?php

require_once 'AppController.php';
require_once __DIR__ . '/../models/Table.php';
require_once __DIR__ . '/../repository/TableRepository.php';


class TableController extends AppController
{

    //private $message = [];
    private $tableRepository;


    public function __construct()
    {
        parent::__construct();
        $this->tableRepository = new TableRepository();
    }


    public function seeAllTables()
    {
        //wyswietlamy widok html calculator z podanymi argumentami
        $tables = $this->tableRepository->getAllTables();
        $this->render('tables', ['tables' => $tables]);
    }



    public function likeSelectTable(int $id_board, int $id_table) {
        $this->tableRepository->likeTable($id_board, $id_table);
        http_response_code(200);
    }


    public function dislikeSelectTable(int $id_board, int $id_table) {
        $this->tableRepository->dislikeTable($id_board, $id_table);
        http_response_code(200);
    }


    public function seeContentTable(int $id_table){
        $tables = $this->tableRepository->getTable($id_table);
        $this->render('content_table', ['tables' => $tables]);

    }



}