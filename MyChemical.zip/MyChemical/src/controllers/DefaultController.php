<?php

require_once 'AppController.php';


class DefaultController extends AppController {

    public function index(){ /*home*/
        $this->render('home');
    }

    public function login(){
        $this->render('login');
    }

    public function register(){
        $this->render('register');
    }

    public function content_table(){
        $this->render('content_table');
    }

    public function tables(){
        $this->render('tables');
    }

    public function board(){
        $this->render('board');
    }

    public function account(){
        $this->render('account');
    }

    public function calculators(){
        $this->render('calculators');
    }

    public function calc_molar_mass(){
        $this->render('calc_molar_mass');
    }

}