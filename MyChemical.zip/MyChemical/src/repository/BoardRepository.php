<?php

require_once 'Repository.php';




class BoardRepository extends Repository
{

    public function createNewBoard(?User $new_user){

        //nie trzeba id_board
        $stmt = $this->database->connect()->prepare('INSERT INTO public.board (id_user) VALUES (?)');

        $value = $new_user->getEmail();
        $stmt2 = $this->database->connect()->prepare('SELECT id_user FROM public.user WHERE email = :email');
        $stmt2->bindParam(':email', $value);


        //wykonanie zapytania
        $stmt->execute([$stmt2['id_user']]);

        //dane zapisujemy jako tabela asocjacyjna //nazwy kolumn w tabeli bazy danych
        $board = $stmt->fetch(PDO::FETCH_ASSOC);

        //zwraca aktualne id_board utworzonej board
        //return $board['id_board'];
    }



}








