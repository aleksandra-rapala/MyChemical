<?php

require_once 'Repository.php';


class CalculatorRepository extends Repository
{
    public function likeCalculator(int $id_board, int $id_calculator){

        $stmt = $this->database->connect()->prepare('
            INSERT INTO "board-calculator" (id_board, id_calculator)          
            VALUES (?, ?)
        ');

        //wykonanie zapytania //za pytajniki podstawiamy wartości konkretne
        $stmt->execute([
            $id_board,
            $id_calculator
        ]);
    }


    public function dislikeCalculator(int $id_board, int $id_calculator){

        $stmt = $this->database->connect()->prepare('
            DELETE FROM "board-calculator" WHERE id_board=:id_board and id_calculator=:id_calculator)
        ');

        //klucz pod który chcemy podstawić wartość
        $stmt->bindParam(':id_board', $id_board, PDO::PARAM_INT);
        $stmt->bindParam(':id_calculator', $id_calculator, PDO::PARAM_INT);

        //wykonanie zapytania //za pytajniki podstawiamy wartości konkretne
        $stmt->execute();
    }



    //zwraca wszystkie obiekty kalkulatorów jako (nazwa kalkulatora + nazwa zdjęcia)
    public function getAllCalculators(): array
    {
        $result = [];

        $stmt = $this->database->connect()->prepare('
            SELECT * FROM calculator;
        ');
        $stmt->execute();
        $calculators = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($calculators as $calculator) {
            $result[] = new Calculator(
                $calculator['name_calculator'],
                $calculator['img_calculator'],
                $calculator['id_calculator']
            );
        }
        return $result;
    }



    public function getUserCalculator(int $id_user): array
    {
        $result = [];

        $stmt = $this->database->connect()->prepare('
            SELECT * FROM calculator c NATURAL JOIN "board-calculator" bc NATURAL JOIN "user" u WHERE id_user=:id_user
        ');


        $stmt->bindParam(':id_user', $id_user, PDO::PARAM_INT);

        $stmt->execute();
        $calculators = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($calculators as $calculator) {
            $result[] = new Calculator(
            $calculator['name_calculator'],
            $calculator['image_calculator']
            );
        }

        return $result;
    }


}


