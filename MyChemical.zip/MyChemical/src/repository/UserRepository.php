<?php

require_once 'Repository.php';
require_once __DIR__.'/../models/User.php';

class UserRepository extends Repository
{

    //zwraca użytkownika o danym emailu

    public function getUser(string $email): ?User //bedziemy zwracać albo null albo obiekt użytkownika
    {
        //zmienna do której przypisujemy nowe połączenie z bazą danych
        //prepare jako argument dostaje zapytanie sql
        $stmt = $this->database->connect()->prepare('SELECT * FROM public.user WHERE email = :email');

        //podłączenie parametrów pod połączenie, klucz pod któy chcemy podstawic zmienną, trzeci arg to typ
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);

        //wykonanie
        $stmt->execute();

        //dane zapisujemy jako tabela asocjacyjna //nazwy kolumn w tabeli bazy danych
        $user = $stmt->fetch(PDO::FETCH_ASSOC);


        //jeśli nie ma użytkownika o danym emailu to zwracamy wartość pustą null
        if ($user == false) {
            return null; //tutaj nalezy zrobić w przyszłości z try oraz catch
        }

        //zwracamy użytkownika
        return new User(
            $user['email'],  //nazwy kolumn w tabeli bazy danych
            $user['password']
        );
    }






    public function createNewUser(User $tmpUser){

        //nie trzeba id_user
        $stmt = $this->database->connect()->prepare('
            INSERT INTO public.user (email, password)          
            VALUES (?, ?)
        ');



        //wykonanie zapytania //za pytajniki podstawiamy wartości konkretne
        $stmt->execute([
            $tmpUser->getEmail(),
            $tmpUser->getPassword()
        ]);


    }





    public function giveBoardUser(?int $idBoard, ?int $id_user){

        $stmt = $this->database->connect()->prepare('
            UPDATE public.user SET "board" = :idBoard WHERE id_user = :id_user
        ');

        //podłączenie parametrów pod połączenie, klucz pod któy chcemy podstawic zmienną, trzeci arg to typ
        $stmt->bindParam(':id_user', $id_user);
        //podłączenie parametrów pod połączenie, klucz pod któy chcemy podstawic zmienną, trzeci arg to typ
        $stmt->bindParam(':idBoard', $idBoard, PDO::PARAM_INT);

        $stmt->execute();



    }




}