<?php

require_once 'Repository.php';

class TableRepository extends Repository
{


    public function likeTable(int $id_board, int $id_table){

        $stmt = $this->database->connect()->prepare('
            INSERT INTO "board-table" (id_board, id_table)          
            VALUES (?, ?)
        ');

        //wykonanie zapytania //za pytajniki podstawiamy wartości konkretne
        $stmt->execute([
            $id_board,
            $id_table
        ]);
    }


    public function dislikeTable(int $id_board, int $id_table){

        $stmt = $this->database->connect()->prepare('
            DELETE FROM "board-table" WHERE id_board=:id_board and id_table=:id_table)
        ');

        $stmt->bindParam(':id_board', $id_board, PDO::PARAM_INT);
        $stmt->bindParam(':id_table', $id_ctable, PDO::PARAM_INT);

        //wykonanie zapytania //za pytajniki podstawiamy wartości konkretne
        $stmt->execute();
    }



    //zwraca wszystkie obiekty kalkulatorów jako (nazwa kalkulatora + nazwa zdjęcia)
    public function getAllTables(): array
    {
        $result = [];

        $stmt = $this->database->connect()->prepare('
            SELECT * FROM "table";
        ');
        $stmt->execute();
        $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($tables as $table) {
            $result[] = new Table(
                $table['name_table'],
                $table['img_table'],
                $table['id_table'],
                $table['img_content_table']
            );
        }
        return $result;
    }


    public function getTable($id_table): ?array
    {

        $result = [];

        $stmt = $this->database->connect()->prepare('
            SELECT * FROM "table" WHERE id_table=:id_table
        ');


        $stmt->bindParam(':id_table', $id_table, PDO::PARAM_INT);

        $stmt->execute();
        $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($tables as $table) {
            $result[] = new Table(
                $table['name_table'],
                $table['img_table'],
                $table['id_table'],
                $table['img_content_table']);
        }

        return $result;


    }








    public function getUserTable(int $id_user): array
    {
        $result = [];

        $stmt = $this->database->connect()->prepare('
            SELECT * FROM "table" t NATURAL JOIN "board-table" bc NATURAL JOIN "user" u WHERE id_user=:id_user
        ');


        $stmt->bindParam(':id_user', $id_user, PDO::PARAM_INT);

        $stmt->execute();
        $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($tables as $table) {
            $result[] = new Calculator(
                $table['name_table'],
                $table['image_table']
            );
        }

        return $result;
    }


}